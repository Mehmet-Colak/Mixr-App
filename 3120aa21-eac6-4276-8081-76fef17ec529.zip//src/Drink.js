export default function Drink({ name, data }) {
  return data?.drinks?.[0] ? (
    <section id="drinkarea">
      <div>{data.drinks[0].strDrink}</div>
      {/* JSON.stringify(data, null, 2) */}
      <div>
        <img src={data.drinks[0].strDrinkThumb} />
      </div>
      <div>
        <ul>
          {data.drinks[0].strIngredient1 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient1} ({data.drinks[0].strMeasure1})
            </li>
          )}
          {data.drinks[0].strIngredient2 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient2} ({data.drinks[0].strMeasure2})
            </li>
          )}
          {data.drinks[0].strIngredient3 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient3} ({data.drinks[0].strMeasure3})
            </li>
          )}
          {data.drinks[0].strIngredient4 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient4} ({data.drinks[0].strMeasure4})
            </li>
          )}
          {data.drinks[0].strIngredient5 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient5} ({data.drinks[0].strMeasure5})
            </li>
          )}
          {data.drinks[0].strIngredient6 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient6} ({data.drinks[0].strMeasure6})
            </li>
          )}
          {data.drinks[0].strIngredient7 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient7} ({data.drinks[0].strMeasure7})
            </li>
          )}
          {data.drinks[0].strIngredient8 && (
            <li>
              {" "}
              {data.drinks[0].strIngredient8} ({data.drinks[0].strMeasure8})
            </li>
          )}
        </ul>
      </div>
      <div>{data.drinks[0].strInstructions}</div>
    </section>
  ) : (
    <p>Loading....</p>
  );
}
