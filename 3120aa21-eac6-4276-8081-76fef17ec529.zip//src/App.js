import { useEffect, useState } from "react";
import "./styles.css";
import Title from "./Title.js";
import Entry from "./Entry.js";
import Info from "./Info.js";
import Drink from "./Drink.js";

export default function App() {
  const [name, setName] = useState("mojito");
  const [data, setData] = useState("");
  const cocktails = [
    "margarita",
    "mojito",
    "martini",
    "negroni",
    "daiquiri",
    "manhattan",
    "sidecar",
    "gimlet",
    "bellini",
    "sazerac",
    "paloma",
    "spritz",
    "mimosa",
    "aviation",
    "vesper",
    "julep",
    "punch",
    "mai",
    "sling",
    "colada",
  ];

  function randomize() {
    const randomIndex = Math.floor(Math.random() * cocktails.length);
    return setName(cocktails[randomIndex]);
  }
  useEffect(() => {
    const drink_url = `https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${name}`;
    fetch(drink_url)
      .then((r) => r.json())
      .then((r) => setData(r))
      .catch((e) => setData(`${e}`));
  }, [name]);

  return (
    <div className="App">
      <Title text="Welcome to MixR" />
      <p>
        <Button name="I'm thirsty!" action={randomize} />
      </p>
      <Drink name={name} data={data} />
      <footer>
        <a href="https://codesandbox.io/p/sandbox/mixr-694v95?file=%2Fsrc%2FApp.js%3A37%2C55">
          Code Sandbox
        </a>
        <br />
        <a href="https://github.com/Mehmet-Colak/Mixr-App.git">Github</a>
      </footer>
    </div>
  );
}

function Button({ name, action }) {
  return <button onClick={action}>{name}</button>;
}
